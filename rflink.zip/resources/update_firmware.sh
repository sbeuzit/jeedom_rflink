#!/bin/bash
cd $1

rm -rf rflink/*
unzip /tmp/rflink.zip -d rflink/
